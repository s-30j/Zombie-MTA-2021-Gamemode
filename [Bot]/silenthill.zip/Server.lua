﻿--[[
	##########################################################################
	##                                                                      ##
	##        Project: 'Silent Hill' - resource for MTA: San Andreas        ##
	##                                                                      ##
	##########################################################################
	[C] Copyright 2013-2014, Falke
]]
createTeam ( "Silent Hill", 0, 0, 0 )
local SHteam = getTeamFromName ( "Silent Hill" )

zones = { "Angel Pine", "Whetstone" }

function isElementInLeatherfaceZone(element)
	local x, y, z = getElementPosition(element)
	local inZone = false
	for i, zone in ipairs(zones) do
		if getZoneName(x, y, z) == zone then
			inZone = true
		end
	end
	if inZone == true then
		return true
	else
		return false
	end
end
function isLeatherfaceAtmosphere()
	local h, m = getTime()
	if h > 5 then
		return true
	elseif h < 4 then
		return true
	else
		return false
	end
end
addEvent("onPlayerLeatherfaceAreaEnter", true)
addEvent("onPlayerLeatherfaceAreaLeave", true)
addEvent("syncMyTime", true)
addEvent("onGlendaleSpawn", true)
addEventHandler("onGlendaleSpawn", getRootElement(),
	function(x, y, z)
		local glendale = createVehicle(getVehicleModelFromName("Glendale Damaged"), x, y, z + 10)
		local px, py, pz = getElementPosition(source)
		local rotZ = findRotation(x, y, px, py)
		setElementRotation(glendale, 0, 0, rotZ)
		setVehicleEngineState(glendale, true)
		setVehicleLocked(glendale, true)
		setTimer(
			function()
				if isElement(glendale) then
					blowVehicle(glendale)
					local x, y, z = getElementPosition(glendale)
					createExplosion(x, y, z, 7)
					destroyElement(glendale)
				end
			end
		, 20000, 1)
	end
)
addEventHandler("syncMyTime", getRootElement(),
	function()
		local h, m = getTime()
		triggerClientEvent("clientSyncMyTime", source, h, m)
	end
)
addEventHandler("onPlayerLeatherfaceAreaLeave", getRootElement(),
	function()
		local weather = getWeather()
		triggerClientEvent("onClientWeatherChangeRequest", source, weather)
	end
)
addEvent("onScreamPlay", true)
setTimer(
	function()
		if isLeatherfaceAtmosphere() then
			local sound = 1
			if sound == 1 then sound = "siren.mp3" end
			triggerClientEvent("onClientScreamPlay", getRootElement(), sound)
			triggerEvent("onScreamPlay", getRootElement(), sound)
		end
	end
, 25000, 0)





function findRotation(x1,y1,x2,y2)
 
  local t = -math.deg(math.atan2(x2-x1,y2-y1))
  if t < 0 then t = t + 360 end;
  return t;
 
end
function getPointFromDistanceRotation(x, y, dist, angle)
 
    local a = math.rad(90 - angle);
 
    local dx = math.cos(a) * dist;
    local dy = math.sin(a) * dist;
 
    return x+dx, y+dy;
 
end
Alessa = nil
function getPlayerNearestToPosition(x, y, z)
	local nearestPlayer = nil
	local nearestDistance = nil
	for i, players in ipairs(getElementsByType("player")) do
		local px, py, pz = getElementPosition(players)
		local distance = getDistanceBetweenPoints3D(px, py, pz, x, y, z)
		if nearestPlayer == nil then
			nearestPlayer = players
			nearestDistance = distance
		elseif distance < nearestDistance then
			nearestDistance = distance
			nearestPlayer = players
		end
	end
	if nearestPlayer == nil then
		return false
	else
		return nearestPlayer
	end
end
setTimer(
	function()
			local x, y, z = getElementPosition(RealAlessa)
			local player = getPlayerNearestToPosition(x, y, z)
			if player then
				local px, py, pz = getElementPosition(player)
				if getDistanceBetweenPoints3D(x, y, z, px, py, pz) < 150 then
					if isElementInWater(RealAlessa) then
					setPedAnimation(RealAlessa, "CRACK", "crckidle4", -1, true, true, false)
					exports.extra_health:setElementExtraHealth ( RealAlessa, 5000 )
					end
					local rotZ = findRotation(x, y, px, py)
					setPedRotation(RealAlessa, rotZ)
					if getDistanceBetweenPoints3D(px, py, pz, x, y, z) < 10 then
						local health = getElementHealth(player)
						if health < 5 or health == 5 then
							setElementHealth(player, 0)
							local leX, leY, leZ = getElementPosition(RealAlessa)
					setPedAnimation(RealAlessa, "CRACK", "crckidle4", -1, true, true, false)
					exports.extra_health:setElementExtraHealth ( RealAlessa, 5000 )
							createExplosion(leX, leY, leZ, 7)
						else
							setElementHealth(player, health - 2)
						end
					end
				else
			setPedAnimation(RealAlessa, "CRACK", "crckidle4", -1, true, true, false)
			exports.extra_health:setElementExtraHealth ( RealAlessa, 5000 )
				end
			end
		end
, 50, 0)

    function AlessaBoss( )
		local localPed = exports [ "slothBot" ]:spawnBot ( -2145.94, -2410.93, 30.47, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
     		setElementModel ( localPed, 170 )
		local health = exports.extra_health:setElementExtraHealth ( localPed, 5000 )
		setPedAnimation(localPed, "CRACK", "crckidle4", -1, true, true, false)
		setElementData(localPed, "type", "RealAlessa")
		setPedStat(localPed, 24, 1000)
		RealAlessa = localPed
                setElementData(localPed, "currenthealth", exports.extra_health:getElementExtraHealth(RealAlessa))
                setElementData(localPed, "Alessa", true)
	end
addEventHandler("onResourceStart", resourceRoot, AlessaBoss) 


addEventHandler("onPedWasted", getRootElement(),
	function(ammo, killer)
		if isElement(RealAlessa) then
			if source == RealAlessa then
				local x, y, z = getElementPosition(RealAlessa)
				destroyElement(RealAlessa)
				createExplosion(x, y, z, 7)
			end
		end
	end
)

addEvent("AlessaAtack", true)
addEventHandler ( "AlessaAtack", root,
    function ( )
	local Health = exports.extra_health:getElementExtraHealth(RealAlessa)
	local leX, leY, leZ = getElementPosition(RealAlessa)
	setPedAnimation(RealAlessa, "ped", "WALK_old", -1, true, true, false)
	setPedOnFire(RealAlessa,true)

	if Health < 4500 or Health == 4500 then
		local AMonster = exports [ "slothBot" ]:spawnBot ( leX+2, leY, leZ, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
     		setElementModel ( AMonster, 171 )
	if Health < 4450 or Health == 4450 then
	destroyElement(AMonster)

	if Health < 4000 or Health == 4000 then
		local AMonster = exports [ "slothBot" ]:spawnBot ( leX+2, leY, leZ, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
     		setElementModel ( AMonster, 171 )
	if Health < 3935 or Health == 3935 then
	destroyElement(AMonster)

	if Health < 3200 or Health == 3200 then
		local AMonster = exports [ "slothBot" ]:spawnBot ( leX+2, leY, leZ, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
     		setElementModel ( AMonster, 171 )
	if Health < 3090 or Health == 3090 then
	destroyElement(AMonster)

	if Health < 2500 or Health == 2500 then
		local AMonster = exports [ "slothBot" ]:spawnBot ( leX+2, leY, leZ, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
     		setElementModel ( AMonster, 171 )
	if Health < 2300 or Health == 2300 then
	destroyElement(AMonster)

local shskins= math.random ( 172, 176 )
	if Health < 1200 or Health == 1200 then
		local AMonster = exports [ "slothBot" ]:spawnBot ( leX+2, leY, leZ, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
     		setElementModel ( AMonster, shskins )
	if Health < 1000 or Health == 1000 then
	destroyElement(AMonster)

	if Health < 500 or Health == 500 then
		local AMonster = exports [ "slothBot" ]:spawnBot ( leX+2, leY+1, leZ, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 8,         "chasing", true )
     		setElementModel ( AMonster, 170 )
	if Health < 200 or Health == 200 then
	destroyElement(AMonster)
end
end
end
end
end
end
end
end
end
end
end
end
end
)

	function SHPerros ()
			local Perro1 = exports [ "slothBot" ]:spawnBot ( 1272.56, 287.6116, 19.6, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 10,         "chasing", true )
			local Perro2 = exports [ "slothBot" ]:spawnBot ( 1281.40, 301, 19.6, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 10,         "chasing", true )
			local Perro3 = exports [ "slothBot" ]:spawnBot ( 1282.40, 301, 19.6, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 10,         "chasing", true )
     		setElementModel ( Perro1, 172 )
     		setElementModel ( Perro2, 172 )
     		setElementModel ( Perro3, 172 )
		exports.extra_health:setElementInvulnerable ( Perro1, true )
		exports.extra_health:setElementInvulnerable ( Perro2, true )
		exports.extra_health:setElementInvulnerable ( Perro3, true )
		blip[1] = (createBlipAttachedTo ( Perro1, 0 ))
	end
addEventHandler("onResourceStart", resourceRoot, SHPerros) 

addEvent("SHmonsters", true)
addEventHandler ( "SHmonsters", root,
	function ()
		local Monster = exports [ "slothBot" ]:spawnBot ( -2110.44, -2447, 30.5, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster2 = exports [ "slothBot" ]:spawnBot ( -2138.55, -2454, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster3 = exports [ "slothBot" ]:spawnBot ( -2119.42, -2475, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster4 = exports [ "slothBot" ]:spawnBot ( -2104.54, -2499, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster5 = exports [ "slothBot" ]:spawnBot ( -2078.90, -2475, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster6 = exports [ "slothBot" ]:spawnBot ( -2040.95, -2475, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster7 = exports [ "slothBot" ]:spawnBot ( -2088.33, -2529, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster8 = exports [ "slothBot" ]:spawnBot ( -2133.70, -2535, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster9 = exports [ "slothBot" ]:spawnBot ( -2169.71, -2525, 30.5, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster10 = exports [ "slothBot" ]:spawnBot ( -2202.375, -2501, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster11 = exports [ "slothBot" ]:spawnBot ( -2220.91, -2469, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster12 = exports [ "slothBot" ]:spawnBot ( -2227.13, -2440, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster13 = exports [ "slothBot" ]:spawnBot ( -2196.52, -2435, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster14 = exports [ "slothBot" ]:spawnBot ( -2196.52, -2432, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster15 = exports [ "slothBot" ]:spawnBot ( -2189.99, -2405, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster16 = exports [ "slothBot" ]:spawnBot ( -2207.71, -2369, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster17 = exports [ "slothBot" ]:spawnBot ( -2170.45, -2358, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster18 = exports [ "slothBot" ]:spawnBot ( -2160.30, -2323, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster19 = exports [ "slothBot" ]:spawnBot ( -2182.43, -2291, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster20 = exports [ "slothBot" ]:spawnBot ( -2099.69, -2372, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster21 = exports [ "slothBot" ]:spawnBot ( -2142.49, -2382, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster22 = exports [ "slothBot" ]:spawnBot ( -2098.44, -2322, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster23 = exports [ "slothBot" ]:spawnBot ( -2120.19, -2307, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster24 = exports [ "slothBot" ]:spawnBot ( -2074.30, -2292, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster25 = exports [ "slothBot" ]:spawnBot ( -2095.53, -2260, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
		local Monster26 = exports [ "slothBot" ]:spawnBot ( -2132.21, -2254, 30.8, 270,  math.random ( 300, 303 ), 0, 0, SHteam, 0,         "chasing", true )
     	setElementModel ( Monster, 174 )
     	setElementModel ( Monster2, 173 )
     	setElementModel ( Monster3, 172 )
    	setElementModel ( Monster4, 173 )
	setElementModel ( Monster5, 174 )
    	setElementModel ( Monster6, 175 )
   	setElementModel ( Monster7, 176 )
     	setElementModel ( Monster8, 176 )
     	setElementModel ( Monster9, 175 )
     	setElementModel ( Monster10, 172 )
     	setElementModel ( Monster11, 173 )
     	setElementModel ( Monster12, 174 )
     	setElementModel ( Monster13, 175 )
     	setElementModel ( Monster14, 176 )
     	setElementModel ( Monster15, 174 )
     	setElementModel ( Monster16, 175 )
     	setElementModel ( Monster17, 172 )
     	setElementModel ( Monster18, 173 )
     	setElementModel ( Monster19, 174 )
     	setElementModel ( Monster20, 175 )
     	setElementModel ( Monster21, 176 )
     	setElementModel ( Monster22, 173 )
     	setElementModel ( Monster23, 176 )
     	setElementModel ( Monster24, 172 )
     	setElementModel ( Monster25, 173 )
     	setElementModel ( Monster26, 174 )
end
)