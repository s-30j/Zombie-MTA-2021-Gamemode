weaponTable = {
  -- WeapName,WeapAmmo,WeapID,AmmoMag,Type,ModelID,Damage,AmmoOcSlots,AmmoModelID,SpawnLocationPercent{Residential,Industrial,Farm,Supermarket,Military},Description
  -- IDs disponíveis 1878-1882
  {"M4A1","STANAG Mag",31,30,1,2726,3500,0.035,1271,{0,0,0,0,2.4},"Assault Rifle of American origin\nAmmo: M4A1 Mag"},
  {"M16A2","STANAG Mag",31,30,1,2725,3500,0.035,1271,{0,0,0,0,1.5},"ItemDesc"},
  {"FN FAL","FAL Mag",31,30,1,2644,3500,0.035,1271,{0,0,0,0,1.7},"ItemDesc"},
  {"G36C","G36 Mag",31,30,1,1950,2722,0.035,1271,{0,0,0,0,3.8},"ItemDesc"},
  {"G36C SD","G36 Mag",31,30,1,1314,2722,0.035,1271,{0,0,0,0,3.8},"ItemDesc"},
  {"AKS-74 Kobra","AK Mag",31,30,1,2832,3500,0.035,1271,{0,0,0,0,3.8},"ItemDesc"},
  {"AKS (gold)","AK Mag",31,30,1,2833,3500,0.035,1271,{0,0,0,0,3.8},"ItemDesc"},
  {"RPK","AK Mag",31,30,1,2831,4500,0.035,1271,{0,0,0,0,3.8},"ItemDesc"},
  {"SA58-CCO","SA58 Mag",31,30,1,1882,2835,0.035,1271,{0,0,0,0,3.8},"ItemDesc"},

  {"CZ 550","CZ 550 Mag",34,5,1,14787,7700,0.1,2358,{0,0,0,0,1.8},"ItemDesc"},
  {"SVD Dragunov","SVD Mag",34,5,1,1875,8900,0.1,2358,{0,0,0,0,1.5},"ItemDesc"},
  {"SVD CAMO","SVD Mag",34,5,1,1272,8000,0.1,2358,{0,0,0,0,1.2},"ItemDesc"},
  {"M40A3","M24 Mag",34,5,1,1273,8200,0.1,2358,{0,0,0,0,2},"ItemDesc"},
  {"DMR","DMR Mag",34,5,1,1868,13000,0.1,2358,{0,0,0,0,1},"ItemDesc"},
  {"M24","M24 Mag",34,5,1,1869,12000,0.1,2358,{0,0,0,0,6},"ItemDesc"},

  {"M107","10Rnd. M107",34,10,1,1878,150000,0.1,1271,{0,0,0,0,0.2},"ItemDesc"},
  {"AS50","5Rnd. AS50",34,5,1,2549,110000,0.1,1271,{0,0,0,0,0.1},"ItemDesc"},
  {"KSVK","5Rnd. KSVK",34,5,1,1767,120000,0.1,1271,{0,0,0,0,0.3},"ItemDesc"},
  {"Cheytac M200","5Rnd. Cheytac M200",34,5,1,1816,130000,0.1,1271,{0,0,0,0,0.1},"ItemDesc"},

  {"M249 SAW","200Rnd. M249 SAW",30,200,1,1485,3555,0.01,1921,{0,0,0,0,0.2},"ItemDesc"},
  {"Mk 48 Mod 0","100Rnd. Mk 48 Mod 0",30,100,1,1823,8000,0.01,1921,{0,0,0,0,0.3},"ItemDesc"},
  {"M240","100Rnd. M240",30,100,1,1769,8000,0.01,1921,{0,0,0,0,0.3},"ItemDesc"},
  {"PKM","200Rnd. PKM",30,200,1,1813,8000,0.01,1921,{0,0,0,0,0.3},"ItemDesc"},
  {"PKP","200Rnd. PKP",30,200,1,1822,8000,0.01,1921,{0,0,0,0,0.3},"ItemDesc"},

  {"Double-Barreled Shotgun","2Rnd. Slug",25,7,1,1872,4500,0.067,2081,{0.1,1.5,0.3,0,2},"ItemDesc"},
  {"M1014","M1014 Slug",25,7,1,1873,4500,0.067,2081,{0.1,1.5,0.3,0,3},"ItemDesc"},
  {"Remington 870","M1014 Slug",25,7,1,1874,4500,0.067,2081,{0.1,1.5,0.3,0,2},"ItemDesc"},
  {"Winchester 1866","1866 Slug",25,7,1,1860,8900,0.067,2081,{0.1,1,0.3,0,2},"ItemDesc"},
  {"Sawn-Off Shotgun","2Rnd. Slug",26,2,1,1858,2000,0.067,2081,{0.3,0,0,0,2.3},"ItemDesc"},

  {"Crossbow","Crossbow Bolt",33,10,1,1546,5333,0.1,2081,{0.3,0,0.3,0.2,3.5},"ItemDesc"},
  {"MGL-140","MGL-140 Mag",33,10,1,1511,0,0.1,1668,{0,0,0,0,0.7},"ItemDesc"},

  {"TEC-9","TEC-9 Mag",28,30,2,1867,1000,0.025,2041,{1,2,0,2,3},"ItemDesc"}, -- NOT DAYZ WEAPON
  {"PDW","PDW Mag",28,30,2,1484,889,0.025,2041,{1,2,0,2,4},"ItemDesc"},
  {"Bizon PP-19","Bizon PP-19 Mag",29,20,2,1866,889,0.025,2041,{0.4,0,0,0.5,5},"ItemDesc"},
  {"MP5A5","MP5 Mag",29,20,2,2059,889,0.025,2041,{0.4,0,0,0.5,2.8},"ItemDesc"},
  {"MP5SD6","MP5 SD Mag",29,20,2,2061,889,0.025,2041,{0.4,0,0,0.5,2.8},"ItemDesc"},

  {"Machete","others",4,0,2,1852,1500,0,0,{3,2,4,3,2},"ItemDesc"},
  {"Chainsaw","others",9,0,2,1853,1000,0,0,{0,2,4,0,0},"ItemDesc"},
  {"Hatchet","others",8,0,2,1854,1006,0,0,{1,1.5,0,2.1,2.1},"ItemDesc"},
  {"Baseball Bat","others",5,0,2,1855,800,0,0,{3,1.5,0,1.4,0},"ItemDesc"},
  {"Baseball Bat Barbed","others",5,0,2,1870,950,0,0,{3,1.5,0,1.4,0},"ItemDesc"},
  {"Baseball Bat With Nails","others",5,0,2,1871,1100,0,0,{3,1.5,0,1.4,0},"ItemDesc"},
  {"Crowbar","others",2,0,2,1857,953,0,0,{3,1.5,0,1.9,0},"ItemDesc"},
  {"Shovel","others",6,0,2,1856,953,0,0,{3,1.5,0,0,1},"ItemDesc"}, -- NOT DAYZ WEAPON

  {"Grenade","others",16,0,3,342,17000,0,0,{0,0,0,0,0.5},"The Explosive Grenade is a explosive device that can be thrown. It is designed to eliminate big groups of hostiles"},
  {"Tear Gas","others",17,0,3,343,0,0,0,{0,0,0,0,1},"The Flashbang is a non-lethal explosive device used to temporarily disorient an enemy's senses"},
  {"Binoculars","others",43,0,3,367,0,0,0,{1,0,2,0,4},"The Binoculars is a hand-held device that can be used to view objects at a distance"},
  {"Parachute","others",46,0,3,371,0,0,0,{0,0,0,0,2},"ItemDesc"},

  {"Makarov PM","Makarov Mag",23,7,4,1861,1389,0.085,3013,{1.5,1.5,4,3.5,5},"ItemDesc"},
  {"Makarov SD","Makarov Mag",23,7,4,1864,1389,0.085,3013,{1.5,1.5,4,3.5,5},"ItemDesc"},
  {"G17","G17 Mag",23,7,4,1862,500,0.085,3013,{1.5,1.5,4,3.5,6},"ItemDesc"},
  {"M1911","M1911 Mag",23,7,4,1253,600,0.085,3013,{1.5,1.5,4,3.5,5},"ItemDesc"},
  {"M9","M9 Mag",23,15,4,1863,900,0.085,3013,{1.9,0,0,0,4},"ItemDesc"},
  {"M9 SD","M9 Mag",23,15,4,1239,800,0.085,3013,{1.9,0,0,0,4},"ItemDesc"},
  {"Desert Eagle","Desert Eagle Mag",24,7,4,1240,1400,0.085,3013,{0.4,0,0.2,0,1},"ItemDesc"}, -- NOT DAYZ WEAPON
  {"Revolver",".45 ACP",24,7,4,1865,4500,0.085,3013,{0.4,0,0.2,0,1.5},"ItemDesc"},
}

function getAllWeapons(player)
  if not isElement(player) then
	player = getLocalPlayer()
  end
  for i,weaponData in pairs(weaponTable)do
	setElementData(player,weaponData[1],1)
	if weaponData[2] ~= "others" then
	  setElementData(player,weaponData[2],100)
	end
  end
end


function isWeaponEquiped(weapType)
  for i,weaponData in pairs(weaponTable)do
	if getElementData(getLocalPlayer(),"currentweapon_"..weapType) == weaponData[1] then
	  return true
	end
  end
  return false
end

function getWeaponAmmoType(weaponName)
  for i,weaponData in pairs(weaponTable)do
	if weaponName == weaponData[1] then
	  if weaponData[2] == "others" then
		return weaponData[1],weaponData[3]
	  else
		return weaponData[2],weaponData[3]
	  end
	end
  end
  return false
end

function getDamageFromName(weapName)
  for i,weaponData in pairs(weaponTable)do
	if weaponData[1] == weapName then
	  return weaponData[7]
	end
  end
  return false
end

function getAmmoPlus(ammo)
  for i,weaponData in pairs(weaponTable)do
	if weaponData[2] == ammo then
	  return weaponData[4]
	end
  end
  return 1
end

function getWeaponDamage(weaponID,player)
  for i,weaponData in pairs(weaponTable)do
	local t,ID = getWeaponAmmoType(weaponData[1])
	if ID == weaponID and (getElementData(player,"currentweapon_1") == weaponData[1] or getElementData(player,"currentweapon_2") == weaponData[1] or getElementData(player,"currentweapon_3") == weaponData[1] or getElementData(player,"currentweapon_4") == weaponData[1]) then
	  if getElementData(getLocalPlayer(),"humanity")== 5000 and(weaponData[5] == 4) then
		return weaponData[7] * 0.3
	  end
	  return weaponData[7]
	end
  end
end