﻿addEvent("playAirdropSound",true)
addEventHandler("playAirdropSound",getRootElement(),function()
  if (getElementData(getLocalPlayer(),"Radio Device") or 0) >= 1 then
	playSound("Sounds/Airdrop"..math.random(1)..".mp3")
  end
end)